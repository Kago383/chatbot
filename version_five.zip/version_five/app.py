from flask import Flask, request, jsonify, render_template
from core.response_generator import ResponseGenerator
import json
import os
from datetime import datetime
from uuid import uuid4

app = Flask(__name__)

# Configuration
app.config['KNOWLEDGE_BASE_PATH'] = 'data/knowledge_base.json'
app.config['CHAT_LOGS_DIR'] = 'data/chat_logs'
app.config['CONVERSATION_HISTORY_DIR'] = 'data/conversations'

def load_knowledge_base():
    os.makedirs('data', exist_ok=True)
    kb_path = app.config['KNOWLEDGE_BASE_PATH']

    if not os.path.exists(kb_path):
        default_kb = {
            "entries": [
                {
                    "intent": "data_bundles",
                    "keywords": ["data bundle", "internet", "data plan", "mobile data", "buy data"],
                    "response": "Mascom offers various data bundles:\n1. Daily Bundle - 100MB for P5\n2. Weekly Bundle - 500MB for P25\n3. Monthly Bundle - 2GB for P99\n\nDial *141# to purchase or check available options.",
                    "follow_up": {
                        "questions": ["How do I buy?", "What are the prices?", "How to check balance?"],
                        "responses": [
                            "To buy a bundle, dial *141# and follow the menu options.",
                            "Prices range from P5 for daily bundles to P299 for large monthly bundles.",
                            "Dial *123# to check your data balance."
                        ]
                    }
                },
                {
                    "intent": "balance_check",
                    "keywords": ["balance", "check balance", "airtime", "remaining"],
                    "response": "To check your balance:\n1. For airtime: Dial *123#\n2. For data: Dial *140#\n3. For bonus: Dial *126#",
                    "examples": ["How much airtime do I have?", "What's my data balance?"]
                }
            ],
            "greetings": [
                "hello", "hi", "hey", "good morning", "good afternoon"
            ],
            "farewells": [
                "bye", "goodbye", "see you", "thanks", "thank you"
            ]
        }
        with open(kb_path, 'w') as f:
            json.dump(default_kb, f)
        return default_kb

    try:
        with open(kb_path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error loading KB: {e}")
        return {"entries": []}

def setup_directories():
    os.makedirs(app.config['CHAT_LOGS_DIR'], exist_ok=True)
    os.makedirs(app.config['CONVERSATION_HISTORY_DIR'], exist_ok=True)

def log_interaction(session_id, user_msg, bot_resp):
    try:
        log_date = datetime.now().strftime('%Y-%m-%d')
        log_file = os.path.join(app.config['CHAT_LOGS_DIR'], f'{log_date}.log')
        
        with open(log_file, 'a') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"{timestamp}\t{session_id}\tUSER: {user_msg}\tBOT: {bot_resp}\n")
    except Exception as e:
        print(f"Logging failed: {e}")

def get_conversation_history(session_id):
    history_file = os.path.join(app.config['CONVERSATION_HISTORY_DIR'], f'{session_id}.json')
    if os.path.exists(history_file):
        try:
            with open(history_file) as f:
                return json.load(f)
        except:
            return []
    return []

def save_conversation_history(session_id, history):
    history_file = os.path.join(app.config['CONVERSATION_HISTORY_DIR'], f'{session_id}.json')
    try:
        with open(history_file, 'w') as f:
            json.dump(history[-20:], f)  # Keep last 20 messages
    except Exception as e:
        print(f"Failed to save conversation history: {e}")

# Initialize
setup_directories()
knowledge_base = load_knowledge_base()
response_generator = ResponseGenerator(knowledge_base)

@app.route('/')
def chat_page():
    return render_template('chat.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        session_id = data.get('session_id', str(uuid4()))
        
        if not user_message:
            return jsonify({'error': 'Empty message'}), 400
        
        # Get conversation history
        history = get_conversation_history(session_id)
        
        # Generate response with context
        bot_response = response_generator.get_response(user_message, history)
        
        # Update history
        history.append({'user': user_message, 'bot': bot_response})
        save_conversation_history(session_id, history)
        
        # Log interaction
        log_interaction(session_id, user_message, bot_response)
        
        return jsonify({
            'response': bot_response,
            'session_id': session_id
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)