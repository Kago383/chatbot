# Chatbot System - Version Five

## Overview

This project is a lightweight, modular chatbot system built with Python. It includes a simple web interface, a conversation engine, and a JSON-based knowledge base. It can log conversations and generate context-aware responses, making it suitable for educational, informational, or customer-service use cases.

## Features

* Web-based chat interface (HTML frontend)
* Response generation logic (`response_generator.py`)
* Session-based chat logging
* JSON-based knowledge base

## Project Structure

```
version_five/
├── app.py                          # Main Flask app entry point
├── core/
│   └── response_generator.py       # Core logic for generating chatbot responses
├── data/
│   ├── knowledge_base.json         # Custom knowledge base
│   ├── chat_logs/                  # Saved logs of past chats
│   └── conversations/              # Structured user session data
└── templates/
    └── chat.html                   # Chat UI template
```

## Getting Started

### Prerequisites

* Python 3.10+
* Flask

### Installation

1. Clone or extract this repository.
2. Navigate into the project directory:

```bash
cd version_five
```

3. Install dependencies:

```bash
pip install flask
```

### Running the Application

```bash
python app.py
```

Visit `http://127.0.0.1:5000/` in your browser to use the chatbot.

## Customization

* Modify `data/knowledge_base.json` to add or change predefined Q\&A pairs.
* Extend `core/response_generator.py` to improve response logic (e.g., NLP integration).
* Update `chat.html` to enhance the user interface.

## Logs and Data

* Conversations are stored as JSON in the `data/conversations/` folder.
* Basic logs are saved in `data/chat_logs/`.

## License

This project is currently not licensed. You can modify or extend it for personal or educational purposes.

---

Feel free to contribute or suggest improvements!
