import requests
import re
from difflib import SequenceMatcher
from typing import List, Dict, Optional, Tuple
import time
import random

class ResponseGenerator:
    def __init__(self, knowledge_base):
        self.knowledge_base = knowledge_base
        self.api_token = "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"
        self.model_url = "https://api-inference.huggingface.co/models/google/flan-t5-base"
        self.min_confidence = 0.6  # Minimum confidence score for KB matches
        self.fallback_responses = [
            "I'm not sure I understand. Could you rephrase your question?",
            "I don't have information on that. Would you like me to connect you to a human agent?",
            "I'm still learning. Could you ask about something else?",
            "Let me check that for you. In the meantime, you might find this helpful: [related info]"
        ]
        
    def get_response(self, message: str, history: List[Dict]) -> Dict:
        message = message.lower().strip()
        response_data = {
            'response': '',
            'intent': None,
            'quick_replies': []
        }
        
        # Check for greetings
        if self.is_greeting(message):
            response_data['response'] = self.get_greeting_response()
            response_data['intent'] = 'greeting'
            response_data['quick_replies'] = self.get_default_quick_replies()
            return response_data
            
        # Check for farewells
        if self.is_farewell(message):
            response_data['response'] = "Thank you for contacting Mascom. Have a great day!"
            response_data['intent'] = 'farewell'
            return response_data
        
        # Check if this is a follow-up question
        follow_up_response = self.handle_follow_up(message, history)
        if follow_up_response:
            response_data.update(follow_up_response)
            return response_data
        
        # Try knowledge base first
        best_match = self.find_best_kb_match(message)
        if best_match and best_match['confidence'] >= self.min_confidence:
            response_data['response'] = best_match['response']
            response_data['intent'] = best_match['intent']
            response_data['quick_replies'] = self.get_quick_replies_for_intent(best_match['intent'])
            return response_data
        
        # Fallback to HuggingFace model with better prompt
        hf_response = self.query_huggingface_model(message, history)
        response_data['response'] = hf_response
        response_data['intent'] = 'unknown'
        response_data['quick_replies'] = self.get_default_quick_replies()
        return response_data
    
    def get_greeting_response(self):
        greetings = [
            "Hello! Welcome to Mascom customer support. How can I help you today?",
            "Hi there! I'm your Mascom assistant. What can I do for you?",
            "Good day! Thank you for contacting Mascom. How may I assist you?"
        ]
        return random.choice(greetings)
    
    def is_greeting(self, message: str) -> bool:
        greetings = self.knowledge_base.get('greetings', [])
        return any(greeting in message for greeting in greetings)
    
    def is_farewell(self, message: str) -> bool:
        farewells = self.knowledge_base.get('farewells', [])
        return any(farewell in message for farewell in farewells)
    
    def handle_follow_up(self, message: str, history: List[Dict]) -> Optional[Dict]:
        if not history:
            return None
            
        # Get last bot response
        last_bot_response = history[-1]['bot'] if history else ""
        
        # Check if last response had follow-up options
        for entry in self.knowledge_base.get('entries', []):
            if entry.get('response', '') in last_bot_response and entry.get('follow_up'):
                for i, question in enumerate(entry['follow_up']['questions']):
                    if self.similarity(message, question.lower()) > 0.7:
                        return {
                            'response': entry['follow_up']['responses'][i],
                            'intent': entry['intent'],
                            'quick_replies': self.get_quick_replies_for_intent(entry['intent'])
                        }
        return None
    
    def find_best_kb_match(self, message: str) -> Optional[Dict]:
        best_match = None
        best_score = 0
        
        for entry in self.knowledge_base.get('entries', []):
            for keyword in entry.get('keywords', []):
                # Check for exact match first
                if f' {keyword} ' in f' {message} ':
                    return {
                        'response': entry['response'],
                        'confidence': 1.0,
                        'intent': entry['intent']
                    }
                
                # Calculate similarity score
                score = self.similarity(message, keyword)
                if score > best_score:
                    best_score = score
                    best_match = entry
        
        if best_match and best_score >= self.min_confidence:
            return {
                'response': best_match['response'],
                'confidence': best_score,
                'intent': best_match['intent']
            }
        return None
    
    def similarity(self, a: str, b: str) -> float:
        return SequenceMatcher(None, a, b).ratio()
    
    def get_quick_replies_for_intent(self, intent: str) -> List[str]:
        """Get suggested quick replies based on the detected intent"""
        for entry in self.knowledge_base.get('entries', []):
            if entry.get('intent') == intent:
                if entry.get('follow_up') and entry['follow_up'].get('questions'):
                    return entry['follow_up']['questions']
        return self.get_default_quick_replies()
    
    def get_default_quick_replies(self) -> List[str]:
        """Get default quick replies when no specific intent is detected"""
        return [
            "Check my balance",
            "Buy data bundle",
            "Contact customer care"
        ]
    
    def query_huggingface_model(self, prompt: str, history: List[Dict]) -> str:
        if not self.api_token or self.api_token == "YOUR_HUGGINGFACE_API_KEY":
            return random.choice(self.fallback_responses)
            
        headers = {"Authorization": f"Bearer {self.api_token}"}
        
        # Build context from history
        context = "You are a helpful customer support agent for Mascom Botswana. "
        context += "Here is the conversation history:\n"
        for msg in history[-3:]:  # Use last 3 messages for context
            context += f"User: {msg['user']}\n"
            context += f"Agent: {msg['bot']}\n"
        
        full_prompt = f"{context}\nUser: {prompt}\nAgent:"
        
        payload = {
            "inputs": full_prompt,
            "parameters": {
                "max_length": 200,
                "temperature": 0.7,
                "do_sample": True,
                "top_k": 50,
                "top_p": 0.95
            }
        }
        
        try:
            response = requests.post(self.model_url, headers=headers, json=payload)
            response.raise_for_status()
            
            result = response.json()
            
            if isinstance(result, list):
                if len(result) > 0 and isinstance(result[0], dict):
                    return result[0].get('generated_text', random.choice(self.fallback_responses))
                return result[0] if len(result) > 0 else random.choice(self.fallback_responses)
            
            return random.choice(self.fallback_responses)
        except requests.exceptions.RequestException as e:
            print(f"API Error: {e}")
            return "I'm having trouble connecting to our service. Please try again later or contact customer care at 12345."
        except Exception as e:
            print(f"Unexpected error: {e}")
            return random.choice(self.fallback_responses)